import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:weather_now/bloc/weather_bloc.dart';
import 'package:weather_now/screens/widgets/blurred_container.dart';
import 'package:weather_now/screens/widgets/vertical_container.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _buttonText = 'Show Temperature';

  String getWeatherIcon(int? code) {
    if (code == null) return 'assets/images/1.png';
    if (code >= 200 && code < 300) return 'assets/images/1.png'; // Thunderstorm
    if (code >= 300 && code < 400) return 'assets/images/2.png'; // Drizzle
    if (code >= 500 && code < 600) return 'assets/images/3.png'; // Rain
    if (code >= 600 && code < 700) return 'assets/images/4.png'; // Snow
    if (code >= 700 && code < 800) return 'assets/images/5.png'; // Atmosphere
    if (code == 800) return 'assets/images/6.png'; // Clear
    if (code > 800 && code <= 804) return 'assets/images/7.png'; // Clouds
    return 'assets/images/1.png';
  }

  String getStartEndTime(DateTime? date) {
    if (date == null) return '';
    return DateFormat('jm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarBrightness: Brightness.dark,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(40, 1.2 * kToolbarHeight, 40, 20),
        child: BlocBuilder<WeatherBloc, WeatherState>(
          builder: (context, state) {
            if (state is WeatherSuccess) {
              return SizedBox(
                height: MediaQuery.of(context).size.height,
                child: Stack(
                  children: [
                    Align(
                      alignment: const AlignmentDirectional(30, -0.2),
                      child: Container(
                        height: 300,
                        width: 300,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.yellow,
                        ),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(-30, -0.2),
                      child: Container(
                        height: 300,
                        width: 300,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.lightBlue,
                        ),
                      ),
                    ),
                    Align(
                      alignment: const AlignmentDirectional(1, -1.1),
                      child: Container(
                        height: 300,
                        width: 300,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.deepPurpleAccent,
                        ),
                      ),
                    ),
                    BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 50.0, sigmaY: 100.0),
                      child: Container(
                        decoration: const BoxDecoration(
                          color: Colors.transparent,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const Icon(
                                Icons.location_on_outlined,
                                color: Colors.black,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '${state.weather.areaName}',
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w300,
                                ),
                              ),
                            ],
                          ),
                          const Text(
                            'Good Morning Folks',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8.0),
                          //getWeatherIcon(state.weather.weatherConditionCode),
                          Center(
                            child: BlurredContainer(
                              celsiusText: Text(
                                '${state.weather.temperature!.celsius?.roundToDouble()}°C',
                                style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 40,
                                ),
                              ),
                              getWeatherIcon: Image.asset(
                                getWeatherIcon(
                                  state.weather.weatherConditionCode,
                                ),
                                height: 140,
                                width: 120,
                              ),
                              weatherMain: Text(
                                state.weather.weatherMain!.toUpperCase(),
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 20,
                                ),
                              ),
                              weatherDate: Text(
                                DateFormat(
                                  'EEEE MM-dd-yy -',
                                ).add_jm().format(state.weather.date!),
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 30),
                          // Temperature Button
                          Center(
                            child: Semantics(
                              label: 'temperature_button',
                              button: true,
                              enabled: true,
                              child: ElevatedButton(
                                key: const ValueKey('temperature_button'),
                                onPressed: () {
                                  setState(() {
                                    _buttonText =
                                        '${state.weather.temperature!.celsius?.roundToDouble()}°C';
                                  });
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 30,
                                    vertical: 15,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: Text(
                                  _buttonText,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 30),
                          Text(
                            'Every 3 Hrs - Forecast',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            height: 160,
                            child: ListView.separated(
                              key: const ValueKey('forecast_list'),
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, index) {
                                return VerticalContainer(
                                  imageURL: getWeatherIcon(
                                    state
                                        .weatherList[index]
                                        .weatherConditionCode,
                                  ),
                                  celsiusText:
                                      '${state.weatherList[index].temperature!.celsius?.roundToDouble()}°C',
                                  weatherDesc:
                                      state
                                          .weatherList[index]
                                          .weatherDescription
                                          .toString(),
                                  day: DateFormat(
                                    'EEEE',
                                  ).format(state.weatherList[index].date!),
                                  dateString: DateFormat(
                                    'MM-dd-yy',
                                  ).format(state.weatherList[index].date!),
                                  startTime: getStartEndTime(
                                    state.weatherList[index].date!,
                                  ),
                                );
                              },
                              separatorBuilder:
                                  (context, index) => const SizedBox(width: 10),
                              itemCount: state.weatherList.length,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            } else if (state is WeatherLoading) {
              return const Center(child: CircularProgressIndicator());
            } else {
              return const Center(child: Text('Error loading weather data'));
            }
          },
        ),
      ),
    );
  }
}
