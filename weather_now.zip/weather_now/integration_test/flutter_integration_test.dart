import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart' as integration; // Ensure you have this import
// Add as app because we want to make sure the app loaded correctly on the device by calling the main function in the main dart file.
import 'package:weather_now/main.dart' as app;
void main() {

  // Ensure IntegrationTestWidgetsFlutterBinding is initialized
  final binding = integration.IntegrationTestWidgetsFlutterBinding.ensureInitialized() as integration.IntegrationTestWidgetsFlutterBinding;


  group('E2E Test With Flutter', (){
    tearDownAll(() async {
      // Signal that the test is complete
      binding.reportData = <String, dynamic>{
        'completed': true,
      };
    });

    testWidgets("Test Show Temperature Button in Home Screen", 
    (tester) async {
      app.main();
      await tester.pumpAndSettle(); // wait for app to be ready. 
      
      // Find the temperature button by its key
      final temperatureButton = find.byKey(const ValueKey('temperature_button'));
      
      // Verify the button exists
      expect(temperatureButton, findsOneWidget);
      
      // Verify initial button text is 'Show Temperature'
      expect(find.text('Show Temperature'), findsOneWidget);
      
      // Tap the button
      await tester.tap(temperatureButton);
      await tester.pumpAndSettle();
      
      // Verify the button text changes to show temperature (should contain '°C')
      expect(find.textContaining('°C'), findsWidgets);
      
      // Verify 'Show Temperature' text is no longer present on the button
      expect(find.descendant(
        of: temperatureButton,
        matching: find.text('Show Temperature')
      ), findsNothing);
    });
  });
}