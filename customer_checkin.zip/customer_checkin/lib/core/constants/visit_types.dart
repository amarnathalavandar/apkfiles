class VisitTypes {
  static const List<String> types = [
    'Business Meeting',
    'Interview',
    'Delivery',
    'Contractor',
    'Consultation',
    'Training',
    'Maintenance',
    'Other',
  ];
  
  static String getDefault() => types.first;
}
