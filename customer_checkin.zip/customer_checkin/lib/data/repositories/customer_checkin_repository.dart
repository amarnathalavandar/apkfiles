import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/customer_checkin_model.dart';

class CustomerCheckinRepository {
  static const String _checkinKey = 'customer_checkins';
  
  final SharedPreferences _prefs;
  
  CustomerCheckinRepository(this._prefs);
  
  // Save checkins
  Future<bool> saveCheckins(List<CustomerCheckin> checkins) async {
    try {
      final checkinList = CustomerCheckinList(checkins: checkins);
      final jsonString = jsonEncode(checkinList.toJson());
      return await _prefs.setString(_checkinKey, jsonString);
    } catch (e) {
      return false;
    }
  }
  
  // Get all checkins
  Future<List<CustomerCheckin>> getCheckins() async {
    try {
      final jsonString = _prefs.getString(_checkinKey);
      if (jsonString == null) return _getDummyData();
      
      final checkinList = CustomerCheckinList.fromJson(
        jsonDecode(jsonString) as Map<String, dynamic>,
      );
      return checkinList.checkins;
    } catch (e) {
      return _getDummyData();
    }
  }
  
  // Add new checkin
  Future<bool> addCheckin(CustomerCheckin checkin) async {
    final checkins = await getCheckins();
    final mutableList = List<CustomerCheckin>.from(checkins);
    mutableList.insert(0, checkin);
    return await saveCheckins(mutableList);
  }
  
  // Update checkin
  Future<bool> updateCheckin(CustomerCheckin checkin) async {
    final checkins = await getCheckins();
    final mutableList = List<CustomerCheckin>.from(checkins);
    final index = mutableList.indexWhere((c) => c.id == checkin.id);
    if (index != -1) {
      mutableList[index] = checkin;
      return await saveCheckins(mutableList);
    }
    return false;
  }
  
  // Get upcoming checkins
  Future<List<CustomerCheckin>> getUpcomingCheckins() async {
    final checkins = await getCheckins();
    final now = DateTime.now();
    return checkins.where((c) {
      if (c.expectedAt == null) return false;
      return c.expectedAt!.isAfter(now) && c.status == 'upcoming';
    }).toList();
  }
  
  // Get previous checkins
  Future<List<CustomerCheckin>> getPreviousCheckins() async {
    final checkins = await getCheckins();
    final now = DateTime.now();
    return checkins.where((c) {
      if (c.expectedAt == null) return true;
      return c.expectedAt!.isBefore(now) || c.status == 'checked-out';
    }).toList();
  }
  
  // Dummy data
  List<CustomerCheckin> _getDummyData() {
    final now = DateTime.now();
    
    return [
      // Upcoming visits
      CustomerCheckin(
        id: '1',
        visitorName: 'John Smith',
        visitorEmail: 'john.smith@example.com',
        companyName: 'Tech Corp',
        phone: '+1234567890',
        hostName: 'Test Host',
        visitType: 'Business Meeting',
        checkinTime: now.add(const Duration(hours: 2)),
        status: 'upcoming',
        expectedAt: now.add(const Duration(hours: 2)),
        leavingAt: now.add(const Duration(hours: 4)),
        notes: 'Quarterly business review',
      ),
      CustomerCheckin(
        id: '2',
        visitorName: 'Sarah Johnson',
        visitorEmail: 'sarah.j@example.com',
        companyName: 'Design Studio',
        phone: '+1234567891',
        hostName: 'Test Host',
        visitType: 'Interview',
        checkinTime: now.add(const Duration(hours: 5)),
        status: 'upcoming',
        expectedAt: now.add(const Duration(hours: 5)),
        leavingAt: now.add(const Duration(hours: 6)),
        notes: 'Senior designer position',
      ),
      CustomerCheckin(
        id: '3',
        visitorName: 'Michael Brown',
        visitorEmail: 'mbrown@example.com',
        companyName: 'Consulting Group',
        phone: '+1234567892',
        hostName: 'Test Host',
        visitType: 'Consultation',
        checkinTime: now.add(const Duration(days: 1)),
        status: 'upcoming',
        expectedAt: now.add(const Duration(days: 1)),
        leavingAt: now.add(const Duration(days: 1, hours: 2)),
        notes: 'Strategic planning session',
      ),
      
      // Previous visits
      CustomerCheckin(
        id: '4',
        visitorName: 'Emily Davis',
        visitorEmail: 'emily.d@example.com',
        companyName: 'Marketing Inc',
        phone: '+1234567893',
        hostName: 'Test Host',
        visitType: 'Delivery',
        checkinTime: now.subtract(const Duration(hours: 3)),
        checkoutTime: now.subtract(const Duration(hours: 2)),
        status: 'checked-out',
        expectedAt: now.subtract(const Duration(hours: 3)),
        leavingAt: now.subtract(const Duration(hours: 2)),
        notes: 'Document delivery',
      ),
      CustomerCheckin(
        id: '5',
        visitorName: 'Robert Wilson',
        visitorEmail: 'rwilson@example.com',
        companyName: 'Sales Corp',
        phone: '+1234567894',
        hostName: 'Test Host',
        visitType: 'Business Meeting',
        checkinTime: now.subtract(const Duration(days: 1)),
        checkoutTime: now.subtract(const Duration(days: 1)).add(const Duration(hours: 2)),
        status: 'checked-out',
        expectedAt: now.subtract(const Duration(days: 1)),
        leavingAt: now.subtract(const Duration(days: 1)).add(const Duration(hours: 2)),
        notes: 'Product demonstration',
      ),
      CustomerCheckin(
        id: '6',
        visitorName: 'Lisa Anderson',
        visitorEmail: 'landerson@example.com',
        companyName: 'Finance Solutions',
        phone: '+1234567895',
        hostName: 'Test Host',
        visitType: 'Contractor',
        checkinTime: now.subtract(const Duration(days: 2)),
        checkoutTime: now.subtract(const Duration(days: 2)).add(const Duration(hours: 4)),
        status: 'checked-out',
        expectedAt: now.subtract(const Duration(days: 2)),
        leavingAt: now.subtract(const Duration(days: 2)).add(const Duration(hours: 4)),
        notes: 'System maintenance',
      ),
    ];
  }
}
