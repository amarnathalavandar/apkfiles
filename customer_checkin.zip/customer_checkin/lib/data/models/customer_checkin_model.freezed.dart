// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'customer_checkin_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

CustomerCheckin _$CustomerCheckinFromJson(Map<String, dynamic> json) {
  return _CustomerCheckin.fromJson(json);
}

/// @nodoc
mixin _$CustomerCheckin {
  String get id => throw _privateConstructorUsedError;
  String get visitorName => throw _privateConstructorUsedError;
  String get visitorEmail => throw _privateConstructorUsedError;
  String? get companyName => throw _privateConstructorUsedError;
  String? get phone => throw _privateConstructorUsedError;
  String get hostName => throw _privateConstructorUsedError;
  String get visitType => throw _privateConstructorUsedError;
  DateTime get checkinTime => throw _privateConstructorUsedError;
  DateTime? get checkoutTime => throw _privateConstructorUsedError;
  String get status =>
      throw _privateConstructorUsedError; // 'checked-in', 'checked-out', 'upcoming'
  String? get notes => throw _privateConstructorUsedError;
  DateTime? get expectedAt => throw _privateConstructorUsedError;
  DateTime? get leavingAt => throw _privateConstructorUsedError;

  /// Serializes this CustomerCheckin to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of CustomerCheckin
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $CustomerCheckinCopyWith<CustomerCheckin> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CustomerCheckinCopyWith<$Res> {
  factory $CustomerCheckinCopyWith(
    CustomerCheckin value,
    $Res Function(CustomerCheckin) then,
  ) = _$CustomerCheckinCopyWithImpl<$Res, CustomerCheckin>;
  @useResult
  $Res call({
    String id,
    String visitorName,
    String visitorEmail,
    String? companyName,
    String? phone,
    String hostName,
    String visitType,
    DateTime checkinTime,
    DateTime? checkoutTime,
    String status,
    String? notes,
    DateTime? expectedAt,
    DateTime? leavingAt,
  });
}

/// @nodoc
class _$CustomerCheckinCopyWithImpl<$Res, $Val extends CustomerCheckin>
    implements $CustomerCheckinCopyWith<$Res> {
  _$CustomerCheckinCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of CustomerCheckin
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? visitorName = null,
    Object? visitorEmail = null,
    Object? companyName = freezed,
    Object? phone = freezed,
    Object? hostName = null,
    Object? visitType = null,
    Object? checkinTime = null,
    Object? checkoutTime = freezed,
    Object? status = null,
    Object? notes = freezed,
    Object? expectedAt = freezed,
    Object? leavingAt = freezed,
  }) {
    return _then(
      _value.copyWith(
            id:
                null == id
                    ? _value.id
                    : id // ignore: cast_nullable_to_non_nullable
                        as String,
            visitorName:
                null == visitorName
                    ? _value.visitorName
                    : visitorName // ignore: cast_nullable_to_non_nullable
                        as String,
            visitorEmail:
                null == visitorEmail
                    ? _value.visitorEmail
                    : visitorEmail // ignore: cast_nullable_to_non_nullable
                        as String,
            companyName:
                freezed == companyName
                    ? _value.companyName
                    : companyName // ignore: cast_nullable_to_non_nullable
                        as String?,
            phone:
                freezed == phone
                    ? _value.phone
                    : phone // ignore: cast_nullable_to_non_nullable
                        as String?,
            hostName:
                null == hostName
                    ? _value.hostName
                    : hostName // ignore: cast_nullable_to_non_nullable
                        as String,
            visitType:
                null == visitType
                    ? _value.visitType
                    : visitType // ignore: cast_nullable_to_non_nullable
                        as String,
            checkinTime:
                null == checkinTime
                    ? _value.checkinTime
                    : checkinTime // ignore: cast_nullable_to_non_nullable
                        as DateTime,
            checkoutTime:
                freezed == checkoutTime
                    ? _value.checkoutTime
                    : checkoutTime // ignore: cast_nullable_to_non_nullable
                        as DateTime?,
            status:
                null == status
                    ? _value.status
                    : status // ignore: cast_nullable_to_non_nullable
                        as String,
            notes:
                freezed == notes
                    ? _value.notes
                    : notes // ignore: cast_nullable_to_non_nullable
                        as String?,
            expectedAt:
                freezed == expectedAt
                    ? _value.expectedAt
                    : expectedAt // ignore: cast_nullable_to_non_nullable
                        as DateTime?,
            leavingAt:
                freezed == leavingAt
                    ? _value.leavingAt
                    : leavingAt // ignore: cast_nullable_to_non_nullable
                        as DateTime?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$CustomerCheckinImplCopyWith<$Res>
    implements $CustomerCheckinCopyWith<$Res> {
  factory _$$CustomerCheckinImplCopyWith(
    _$CustomerCheckinImpl value,
    $Res Function(_$CustomerCheckinImpl) then,
  ) = __$$CustomerCheckinImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String id,
    String visitorName,
    String visitorEmail,
    String? companyName,
    String? phone,
    String hostName,
    String visitType,
    DateTime checkinTime,
    DateTime? checkoutTime,
    String status,
    String? notes,
    DateTime? expectedAt,
    DateTime? leavingAt,
  });
}

/// @nodoc
class __$$CustomerCheckinImplCopyWithImpl<$Res>
    extends _$CustomerCheckinCopyWithImpl<$Res, _$CustomerCheckinImpl>
    implements _$$CustomerCheckinImplCopyWith<$Res> {
  __$$CustomerCheckinImplCopyWithImpl(
    _$CustomerCheckinImpl _value,
    $Res Function(_$CustomerCheckinImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of CustomerCheckin
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? visitorName = null,
    Object? visitorEmail = null,
    Object? companyName = freezed,
    Object? phone = freezed,
    Object? hostName = null,
    Object? visitType = null,
    Object? checkinTime = null,
    Object? checkoutTime = freezed,
    Object? status = null,
    Object? notes = freezed,
    Object? expectedAt = freezed,
    Object? leavingAt = freezed,
  }) {
    return _then(
      _$CustomerCheckinImpl(
        id:
            null == id
                ? _value.id
                : id // ignore: cast_nullable_to_non_nullable
                    as String,
        visitorName:
            null == visitorName
                ? _value.visitorName
                : visitorName // ignore: cast_nullable_to_non_nullable
                    as String,
        visitorEmail:
            null == visitorEmail
                ? _value.visitorEmail
                : visitorEmail // ignore: cast_nullable_to_non_nullable
                    as String,
        companyName:
            freezed == companyName
                ? _value.companyName
                : companyName // ignore: cast_nullable_to_non_nullable
                    as String?,
        phone:
            freezed == phone
                ? _value.phone
                : phone // ignore: cast_nullable_to_non_nullable
                    as String?,
        hostName:
            null == hostName
                ? _value.hostName
                : hostName // ignore: cast_nullable_to_non_nullable
                    as String,
        visitType:
            null == visitType
                ? _value.visitType
                : visitType // ignore: cast_nullable_to_non_nullable
                    as String,
        checkinTime:
            null == checkinTime
                ? _value.checkinTime
                : checkinTime // ignore: cast_nullable_to_non_nullable
                    as DateTime,
        checkoutTime:
            freezed == checkoutTime
                ? _value.checkoutTime
                : checkoutTime // ignore: cast_nullable_to_non_nullable
                    as DateTime?,
        status:
            null == status
                ? _value.status
                : status // ignore: cast_nullable_to_non_nullable
                    as String,
        notes:
            freezed == notes
                ? _value.notes
                : notes // ignore: cast_nullable_to_non_nullable
                    as String?,
        expectedAt:
            freezed == expectedAt
                ? _value.expectedAt
                : expectedAt // ignore: cast_nullable_to_non_nullable
                    as DateTime?,
        leavingAt:
            freezed == leavingAt
                ? _value.leavingAt
                : leavingAt // ignore: cast_nullable_to_non_nullable
                    as DateTime?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$CustomerCheckinImpl implements _CustomerCheckin {
  _$CustomerCheckinImpl({
    required this.id,
    required this.visitorName,
    required this.visitorEmail,
    this.companyName,
    this.phone,
    required this.hostName,
    required this.visitType,
    required this.checkinTime,
    this.checkoutTime,
    required this.status,
    this.notes,
    this.expectedAt,
    this.leavingAt,
  });

  factory _$CustomerCheckinImpl.fromJson(Map<String, dynamic> json) =>
      _$$CustomerCheckinImplFromJson(json);

  @override
  final String id;
  @override
  final String visitorName;
  @override
  final String visitorEmail;
  @override
  final String? companyName;
  @override
  final String? phone;
  @override
  final String hostName;
  @override
  final String visitType;
  @override
  final DateTime checkinTime;
  @override
  final DateTime? checkoutTime;
  @override
  final String status;
  // 'checked-in', 'checked-out', 'upcoming'
  @override
  final String? notes;
  @override
  final DateTime? expectedAt;
  @override
  final DateTime? leavingAt;

  @override
  String toString() {
    return 'CustomerCheckin(id: $id, visitorName: $visitorName, visitorEmail: $visitorEmail, companyName: $companyName, phone: $phone, hostName: $hostName, visitType: $visitType, checkinTime: $checkinTime, checkoutTime: $checkoutTime, status: $status, notes: $notes, expectedAt: $expectedAt, leavingAt: $leavingAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CustomerCheckinImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.visitorName, visitorName) ||
                other.visitorName == visitorName) &&
            (identical(other.visitorEmail, visitorEmail) ||
                other.visitorEmail == visitorEmail) &&
            (identical(other.companyName, companyName) ||
                other.companyName == companyName) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.hostName, hostName) ||
                other.hostName == hostName) &&
            (identical(other.visitType, visitType) ||
                other.visitType == visitType) &&
            (identical(other.checkinTime, checkinTime) ||
                other.checkinTime == checkinTime) &&
            (identical(other.checkoutTime, checkoutTime) ||
                other.checkoutTime == checkoutTime) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.notes, notes) || other.notes == notes) &&
            (identical(other.expectedAt, expectedAt) ||
                other.expectedAt == expectedAt) &&
            (identical(other.leavingAt, leavingAt) ||
                other.leavingAt == leavingAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
    runtimeType,
    id,
    visitorName,
    visitorEmail,
    companyName,
    phone,
    hostName,
    visitType,
    checkinTime,
    checkoutTime,
    status,
    notes,
    expectedAt,
    leavingAt,
  );

  /// Create a copy of CustomerCheckin
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$CustomerCheckinImplCopyWith<_$CustomerCheckinImpl> get copyWith =>
      __$$CustomerCheckinImplCopyWithImpl<_$CustomerCheckinImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$CustomerCheckinImplToJson(this);
  }
}

abstract class _CustomerCheckin implements CustomerCheckin {
  factory _CustomerCheckin({
    required final String id,
    required final String visitorName,
    required final String visitorEmail,
    final String? companyName,
    final String? phone,
    required final String hostName,
    required final String visitType,
    required final DateTime checkinTime,
    final DateTime? checkoutTime,
    required final String status,
    final String? notes,
    final DateTime? expectedAt,
    final DateTime? leavingAt,
  }) = _$CustomerCheckinImpl;

  factory _CustomerCheckin.fromJson(Map<String, dynamic> json) =
      _$CustomerCheckinImpl.fromJson;

  @override
  String get id;
  @override
  String get visitorName;
  @override
  String get visitorEmail;
  @override
  String? get companyName;
  @override
  String? get phone;
  @override
  String get hostName;
  @override
  String get visitType;
  @override
  DateTime get checkinTime;
  @override
  DateTime? get checkoutTime;
  @override
  String get status; // 'checked-in', 'checked-out', 'upcoming'
  @override
  String? get notes;
  @override
  DateTime? get expectedAt;
  @override
  DateTime? get leavingAt;

  /// Create a copy of CustomerCheckin
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$CustomerCheckinImplCopyWith<_$CustomerCheckinImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

CustomerCheckinList _$CustomerCheckinListFromJson(Map<String, dynamic> json) {
  return _CustomerCheckinList.fromJson(json);
}

/// @nodoc
mixin _$CustomerCheckinList {
  List<CustomerCheckin> get checkins => throw _privateConstructorUsedError;

  /// Serializes this CustomerCheckinList to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of CustomerCheckinList
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $CustomerCheckinListCopyWith<CustomerCheckinList> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CustomerCheckinListCopyWith<$Res> {
  factory $CustomerCheckinListCopyWith(
    CustomerCheckinList value,
    $Res Function(CustomerCheckinList) then,
  ) = _$CustomerCheckinListCopyWithImpl<$Res, CustomerCheckinList>;
  @useResult
  $Res call({List<CustomerCheckin> checkins});
}

/// @nodoc
class _$CustomerCheckinListCopyWithImpl<$Res, $Val extends CustomerCheckinList>
    implements $CustomerCheckinListCopyWith<$Res> {
  _$CustomerCheckinListCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of CustomerCheckinList
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? checkins = null}) {
    return _then(
      _value.copyWith(
            checkins:
                null == checkins
                    ? _value.checkins
                    : checkins // ignore: cast_nullable_to_non_nullable
                        as List<CustomerCheckin>,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$CustomerCheckinListImplCopyWith<$Res>
    implements $CustomerCheckinListCopyWith<$Res> {
  factory _$$CustomerCheckinListImplCopyWith(
    _$CustomerCheckinListImpl value,
    $Res Function(_$CustomerCheckinListImpl) then,
  ) = __$$CustomerCheckinListImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<CustomerCheckin> checkins});
}

/// @nodoc
class __$$CustomerCheckinListImplCopyWithImpl<$Res>
    extends _$CustomerCheckinListCopyWithImpl<$Res, _$CustomerCheckinListImpl>
    implements _$$CustomerCheckinListImplCopyWith<$Res> {
  __$$CustomerCheckinListImplCopyWithImpl(
    _$CustomerCheckinListImpl _value,
    $Res Function(_$CustomerCheckinListImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of CustomerCheckinList
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({Object? checkins = null}) {
    return _then(
      _$CustomerCheckinListImpl(
        checkins:
            null == checkins
                ? _value._checkins
                : checkins // ignore: cast_nullable_to_non_nullable
                    as List<CustomerCheckin>,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$CustomerCheckinListImpl implements _CustomerCheckinList {
  _$CustomerCheckinListImpl({final List<CustomerCheckin> checkins = const []})
    : _checkins = checkins;

  factory _$CustomerCheckinListImpl.fromJson(Map<String, dynamic> json) =>
      _$$CustomerCheckinListImplFromJson(json);

  final List<CustomerCheckin> _checkins;
  @override
  @JsonKey()
  List<CustomerCheckin> get checkins {
    if (_checkins is EqualUnmodifiableListView) return _checkins;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_checkins);
  }

  @override
  String toString() {
    return 'CustomerCheckinList(checkins: $checkins)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CustomerCheckinListImpl &&
            const DeepCollectionEquality().equals(other._checkins, _checkins));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_checkins));

  /// Create a copy of CustomerCheckinList
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$CustomerCheckinListImplCopyWith<_$CustomerCheckinListImpl> get copyWith =>
      __$$CustomerCheckinListImplCopyWithImpl<_$CustomerCheckinListImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$CustomerCheckinListImplToJson(this);
  }
}

abstract class _CustomerCheckinList implements CustomerCheckinList {
  factory _CustomerCheckinList({final List<CustomerCheckin> checkins}) =
      _$CustomerCheckinListImpl;

  factory _CustomerCheckinList.fromJson(Map<String, dynamic> json) =
      _$CustomerCheckinListImpl.fromJson;

  @override
  List<CustomerCheckin> get checkins;

  /// Create a copy of CustomerCheckinList
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$CustomerCheckinListImplCopyWith<_$CustomerCheckinListImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
