import 'package:freezed_annotation/freezed_annotation.dart';

part 'customer_checkin_model.freezed.dart';
part 'customer_checkin_model.g.dart';

@freezed
class CustomerCheckin with _$CustomerCheckin {
  factory CustomerCheckin({
    required String id,
    required String visitorName,
    required String visitorEmail,
    String? companyName,
    String? phone,
    required String hostName,
    required String visitType,
    required DateTime checkinTime,
    DateTime? checkoutTime,
    required String status, // 'checked-in', 'checked-out', 'upcoming'
    String? notes,
    DateTime? expectedAt,
    DateTime? leavingAt,
  }) = _CustomerCheckin;

  factory CustomerCheckin.fromJson(Map<String, dynamic> json) =>
      _$CustomerCheckinFromJson(json);
}

@freezed
class CustomerCheckinList with _$CustomerCheckinList {
  factory CustomerCheckinList({
    @Default([]) List<CustomerCheckin> checkins,
  }) = _CustomerCheckinList;

  factory CustomerCheckinList.fromJson(Map<String, dynamic> json) =>
      _$CustomerCheckinListFromJson(json);
}
