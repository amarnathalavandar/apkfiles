// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'customer_checkin_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CustomerCheckinImpl _$$CustomerCheckinImplFromJson(
  Map<String, dynamic> json,
) => _$CustomerCheckinImpl(
  id: json['id'] as String,
  visitorName: json['visitorName'] as String,
  visitorEmail: json['visitorEmail'] as String,
  companyName: json['companyName'] as String?,
  phone: json['phone'] as String?,
  hostName: json['hostName'] as String,
  visitType: json['visitType'] as String,
  checkinTime: DateTime.parse(json['checkinTime'] as String),
  checkoutTime:
      json['checkoutTime'] == null
          ? null
          : DateTime.parse(json['checkoutTime'] as String),
  status: json['status'] as String,
  notes: json['notes'] as String?,
  expectedAt:
      json['expectedAt'] == null
          ? null
          : DateTime.parse(json['expectedAt'] as String),
  leavingAt:
      json['leavingAt'] == null
          ? null
          : DateTime.parse(json['leavingAt'] as String),
);

Map<String, dynamic> _$$CustomerCheckinImplToJson(
  _$CustomerCheckinImpl instance,
) => <String, dynamic>{
  'id': instance.id,
  'visitorName': instance.visitorName,
  'visitorEmail': instance.visitorEmail,
  'companyName': instance.companyName,
  'phone': instance.phone,
  'hostName': instance.hostName,
  'visitType': instance.visitType,
  'checkinTime': instance.checkinTime.toIso8601String(),
  'checkoutTime': instance.checkoutTime?.toIso8601String(),
  'status': instance.status,
  'notes': instance.notes,
  'expectedAt': instance.expectedAt?.toIso8601String(),
  'leavingAt': instance.leavingAt?.toIso8601String(),
};

_$CustomerCheckinListImpl _$$CustomerCheckinListImplFromJson(
  Map<String, dynamic> json,
) => _$CustomerCheckinListImpl(
  checkins:
      (json['checkins'] as List<dynamic>?)
          ?.map((e) => CustomerCheckin.fromJson(e as Map<String, dynamic>))
          .toList() ??
      const [],
);

Map<String, dynamic> _$$CustomerCheckinListImplToJson(
  _$CustomerCheckinListImpl instance,
) => <String, dynamic>{'checkins': instance.checkins};
