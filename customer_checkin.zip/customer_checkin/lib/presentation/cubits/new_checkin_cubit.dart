import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../data/models/customer_checkin_model.dart';
import '../../data/repositories/customer_checkin_repository.dart';

part 'new_checkin_state.dart';

class NewCheckinCubit extends Cubit<NewCheckinState> {
  final CustomerCheckinRepository _repository;
  
  NewCheckinCubit(this._repository) : super(const NewCheckinState());
  
  void updateVisitorName(String name) {
    emit(state.copyWith(visitorName: name));
  }
  
  void updateVisitorEmail(String email) {
    emit(state.copyWith(visitorEmail: email));
  }
  
  void updateCompanyName(String company) {
    emit(state.copyWith(companyName: company));
  }
  
  void updatePhone(String phone) {
    emit(state.copyWith(phone: phone));
  }
  
  void updateVisitType(String type) {
    emit(state.copyWith(visitType: type));
  }
  
  void updateExpectedAt(DateTime dateTime) {
    emit(state.copyWith(expectedAt: dateTime));
  }
  
  void updateLeavingAt(DateTime dateTime) {
    emit(state.copyWith(leavingAt: dateTime));
  }
  
  void updateNotes(String notes) {
    emit(state.copyWith(notes: notes));
  }
  
  Future<bool> createCheckin() async {
    if (!state.isValid) return false;
    
    emit(state.copyWith(status: NewCheckinStatus.loading));
    
    try {
      final checkin = CustomerCheckin(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        visitorName: state.visitorName,
        visitorEmail: state.visitorEmail,
        companyName: state.companyName,
        phone: state.phone,
        hostName: 'Test Host',
        visitType: state.visitType,
        checkinTime: state.expectedAt!,
        status: 'upcoming',
        expectedAt: state.expectedAt,
        leavingAt: state.leavingAt,
        notes: state.notes,
      );
      
      final success = await _repository.addCheckin(checkin);
      
      if (success) {
        emit(state.copyWith(status: NewCheckinStatus.success));
        reset();
        return true;
      } else {
        emit(state.copyWith(
          status: NewCheckinStatus.error,
          errorMessage: 'Failed to create customer check-in',
        ));
        return false;
      }
    } catch (e) {
      emit(state.copyWith(
        status: NewCheckinStatus.error,
        errorMessage: e.toString(),
      ));
      return false;
    }
  }
  
  void reset() {
    emit(const NewCheckinState());
  }
}
