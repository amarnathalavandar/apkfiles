part of 'customer_checkin_cubit.dart';

enum CheckinStatus { initial, loading, success, error }

class CustomerCheckinState extends Equatable {
  final CheckinStatus status;
  final List<CustomerCheckin> upcomingCheckins;
  final List<CustomerCheckin> previousCheckins;
  final CustomerCheckin? selectedCheckin;
  final String? errorMessage;
  
  const CustomerCheckinState({
    this.status = CheckinStatus.initial,
    this.upcomingCheckins = const [],
    this.previousCheckins = const [],
    this.selectedCheckin,
    this.errorMessage,
  });
  
  CustomerCheckinState copyWith({
    CheckinStatus? status,
    List<CustomerCheckin>? upcomingCheckins,
    List<CustomerCheckin>? previousCheckins,
    CustomerCheckin? selectedCheckin,
    String? errorMessage,
  }) {
    return CustomerCheckinState(
      status: status ?? this.status,
      upcomingCheckins: upcomingCheckins ?? this.upcomingCheckins,
      previousCheckins: previousCheckins ?? this.previousCheckins,
      selectedCheckin: selectedCheckin ?? this.selectedCheckin,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
  
  @override
  List<Object?> get props => [
    status,
    upcomingCheckins,
    previousCheckins,
    selectedCheckin,
    errorMessage,
  ];
}
