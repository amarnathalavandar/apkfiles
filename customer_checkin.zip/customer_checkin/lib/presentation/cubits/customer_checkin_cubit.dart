import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../data/models/customer_checkin_model.dart';
import '../../data/repositories/customer_checkin_repository.dart';

part 'customer_checkin_state.dart';

class CustomerCheckinCubit extends Cubit<CustomerCheckinState> {
  final CustomerCheckinRepository _repository;
  
  CustomerCheckinCubit(this._repository) : super(const CustomerCheckinState());
  
  CustomerCheckinRepository get repository => _repository;
  
  Future<void> loadCheckins() async {
    emit(state.copyWith(status: CheckinStatus.loading));
    
    try {
      final upcoming = await _repository.getUpcomingCheckins();
      final previous = await _repository.getPreviousCheckins();
      
      emit(state.copyWith(
        status: CheckinStatus.success,
        upcomingCheckins: upcoming,
        previousCheckins: previous,
      ));
    } catch (e) {
      emit(state.copyWith(
        status: CheckinStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }
  
  Future<void> addCheckin(CustomerCheckin checkin) async {
    try {
      final success = await _repository.addCheckin(checkin);
      if (success) {
        await loadCheckins();
      }
    } catch (e) {
      emit(state.copyWith(
        status: CheckinStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }
  
  void selectCheckin(CustomerCheckin checkin) {
    emit(state.copyWith(selectedCheckin: checkin));
  }
}
