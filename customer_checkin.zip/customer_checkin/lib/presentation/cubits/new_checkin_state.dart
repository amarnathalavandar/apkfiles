part of 'new_checkin_cubit.dart';

enum NewCheckinStatus { initial, loading, success, error }

class NewCheckinState extends Equatable {
  final NewCheckinStatus status;
  final String visitorName;
  final String visitorEmail;
  final String companyName;
  final String phone;
  final String visitType;
  final DateTime? expectedAt;
  final DateTime? leavingAt;
  final String notes;
  final String? errorMessage;
  
  const NewCheckinState({
    this.status = NewCheckinStatus.initial,
    this.visitorName = '',
    this.visitorEmail = '',
    this.companyName = '',
    this.phone = '',
    this.visitType = 'Business Meeting',
    this.expectedAt,
    this.leavingAt,
    this.notes = '',
    this.errorMessage,
  });
  
  bool get isValid {
    return visitorName.isNotEmpty &&
           visitorEmail.isNotEmpty &&
           visitType.isNotEmpty &&
           expectedAt != null &&
           leavingAt != null;
  }
  
  NewCheckinState copyWith({
    NewCheckinStatus? status,
    String? visitorName,
    String? visitorEmail,
    String? companyName,
    String? phone,
    String? visitType,
    DateTime? expectedAt,
    DateTime? leavingAt,
    String? notes,
    String? errorMessage,
  }) {
    return NewCheckinState(
      status: status ?? this.status,
      visitorName: visitorName ?? this.visitorName,
      visitorEmail: visitorEmail ?? this.visitorEmail,
      companyName: companyName ?? this.companyName,
      phone: phone ?? this.phone,
      visitType: visitType ?? this.visitType,
      expectedAt: expectedAt ?? this.expectedAt,
      leavingAt: leavingAt ?? this.leavingAt,
      notes: notes ?? this.notes,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
  
  @override
  List<Object?> get props => [
    status,
    visitorName,
    visitorEmail,
    companyName,
    phone,
    visitType,
    expectedAt,
    leavingAt,
    notes,
    errorMessage,
  ];
}
