import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../cubits/customer_checkin_cubit.dart';
import '../widgets/checkin_list_tab.dart';
import '../widgets/new_checkin_wrapper.dart';

class CustomerCheckinHomePage extends StatefulWidget {
  const CustomerCheckinHomePage({super.key});

  @override
  State<CustomerCheckinHomePage> createState() => _CustomerCheckinHomePageState();
}

class _CustomerCheckinHomePageState extends State<CustomerCheckinHomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    context.read<CustomerCheckinCubit>().loadCheckins();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlue,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.primaryWhite),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Customer Check-In',
          style: TextStyle(
            color: AppColors.primaryWhite,
            fontFamily: AppTextStyles.fontFamily,
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primaryWhite,
          labelColor: AppColors.primaryWhite,
          unselectedLabelColor: AppColors.primaryWhite.withOpacity(0.7),
          labelStyle: AppTextStyles.bodyMedium.copyWith(
            fontWeight: FontWeight.w600,
          ),
          tabs: const [
            Tab(text: 'My Check-Ins'),
            Tab(text: 'New Check-In'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          const CheckinListTab(),
          NewCheckinWrapper(
            onCheckInCreated: () {
              _tabController.animateTo(0);
            },
          ),
        ],
      ),
    );
  }
}
