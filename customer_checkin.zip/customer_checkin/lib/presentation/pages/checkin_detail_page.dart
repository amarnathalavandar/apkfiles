import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../data/models/customer_checkin_model.dart';

class CheckinDetailPage extends StatelessWidget {
  final CustomerCheckin checkin;

  const CheckinDetailPage({super.key, required this.checkin});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.primaryBlue,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.primaryWhite),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Check-In Details',
          style: TextStyle(
            color: AppColors.primaryWhite,
            fontFamily: AppTextStyles.fontFamily,
          ),
        ),
        iconTheme: const IconThemeData(color: AppColors.primaryWhite),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Visitor Info Card
            Card(
              color: AppColors.cardBackground,
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            checkin.visitorName,
                            style: AppTextStyles.subheading.copyWith(
                              color: AppColors.primaryBlue,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: _getStatusColor(checkin.status),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            _getStatusText(checkin.status),
                            style: AppTextStyles.bodySmall.copyWith(
                              color: AppColors.primaryWhite,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (checkin.companyName != null) ...[
                      const SizedBox(height: 8),
                      Text(
                        checkin.companyName!,
                        style: AppTextStyles.bodyMedium.copyWith(
                          color: AppColors.secondaryGrey,
                        ),
                      ),
                    ],
                    const SizedBox(height: 16),
                    const Divider(color: AppColors.borderGrey),
                    const SizedBox(height: 16),
                    _buildDetailRow(
                      Icons.email,
                      'Email',
                      checkin.visitorEmail,
                    ),
                    if (checkin.phone != null) ...[
                      const SizedBox(height: 12),
                      _buildDetailRow(
                        Icons.phone,
                        'Phone',
                        checkin.phone!,
                      ),
                    ],
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Visit Info Card
            Card(
              color: AppColors.cardBackground,
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Visit Information',
                      style: AppTextStyles.bodyLarge.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppColors.primaryBlue,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildDetailRow(
                      Icons.person,
                      'Host',
                      checkin.hostName,
                    ),
                    const SizedBox(height: 12),
                    _buildDetailRow(
                      Icons.business_center,
                      'Visit Type',
                      checkin.visitType,
                    ),
                    const SizedBox(height: 12),
                    _buildDetailRow(
                      Icons.calendar_today,
                      'Date',
                      _formatDate(checkin.expectedAt ?? checkin.checkinTime),
                    ),
                    const SizedBox(height: 12),
                    _buildDetailRow(
                      Icons.access_time,
                      'Time',
                      _formatTime(
                        checkin.expectedAt ?? checkin.checkinTime,
                        checkin.leavingAt,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            if (checkin.notes != null && checkin.notes!.isNotEmpty) ...[
              const SizedBox(height: 16),
              Card(
                color: AppColors.cardBackground,
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Notes',
                        style: AppTextStyles.bodyLarge.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppColors.primaryBlue,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        checkin.notes!,
                        style: AppTextStyles.bodyMedium.copyWith(
                          color: AppColors.secondaryGrey,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 20, color: AppColors.secondaryGrey),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTextStyles.bodySmall.copyWith(
                  color: AppColors.secondaryGrey,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: AppTextStyles.bodyMedium.copyWith(
                  color: AppColors.primaryBlack,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'upcoming':
        return AppColors.primaryBlue;
      case 'checked-in':
        return AppColors.successGreen;
      case 'checked-out':
        return AppColors.secondaryGrey;
      default:
        return AppColors.secondaryGrey;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'upcoming':
        return 'Upcoming';
      case 'checked-in':
        return 'Checked In';
      case 'checked-out':
        return 'Checked Out';
      default:
        return status;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('EEEE, MMMM dd, yyyy').format(date);
  }

  String _formatTime(DateTime start, DateTime? end) {
    final startTime = DateFormat('h:mm a').format(start);
    if (end != null) {
      final endTime = DateFormat('h:mm a').format(end);
      return '$startTime - $endTime';
    }
    return startTime;
  }
}
