import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_colors.dart';
import '../../data/repositories/customer_checkin_repository.dart';
import '../cubits/customer_checkin_cubit.dart';
import '../pages/customer_checkin_home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomerCheckinTile extends StatelessWidget {
  const CustomerCheckinTile({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      key: const Key('customer_checkin_tile'),
      onTap: () async {
        final prefs = await SharedPreferences.getInstance();
        final repository = CustomerCheckinRepository(prefs);
        
        if (context.mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BlocProvider(
                create: (_) => CustomerCheckinCubit(repository),
                child: const CustomerCheckinHomePage(),
              ),
            ),
          );
        }
      },
      borderRadius: BorderRadius.circular(12),
      child: Card(
        color: AppColors.cardBackground,
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Container(
          width: 120,
          height: 120,
          padding: const EdgeInsets.all(20),
          child: const Icon(
            Icons.how_to_reg,
            size: 64,
            color: AppColors.primaryBlue,
          ),
        ),
      ),
    );
  }
}
