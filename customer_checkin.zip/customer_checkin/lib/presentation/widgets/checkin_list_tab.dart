import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../cubits/customer_checkin_cubit.dart';
import 'checkin_card.dart';

class CheckinListTab extends StatefulWidget {
  const CheckinListTab({super.key});

  @override
  State<CheckinListTab> createState() => _CheckinListTabState();
}

class _CheckinListTabState extends State<CheckinListTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: AppColors.primaryWhite,
          child: TabBar(
            controller: _tabController,
            indicatorColor: AppColors.primaryBlue,
            labelColor: AppColors.primaryBlue,
            unselectedLabelColor: AppColors.secondaryGrey,
            labelStyle: AppTextStyles.bodyMedium.copyWith(
              fontWeight: FontWeight.w600,
            ),
            tabs: const [
              Tab(text: 'Upcoming'),
              Tab(text: 'Previous'),
            ],
          ),
        ),
        Expanded(
          child: BlocBuilder<CustomerCheckinCubit, CustomerCheckinState>(
            builder: (context, state) {
              if (state.status == CheckinStatus.loading) {
                return const Center(
                  child: CircularProgressIndicator(
                    color: AppColors.primaryBlue,
                  ),
                );
              }

              if (state.status == CheckinStatus.error) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.error_outline,
                        size: 64,
                        color: AppColors.errorRed,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Error loading check-ins',
                        style: AppTextStyles.bodyLarge.copyWith(
                          color: AppColors.secondaryGrey,
                        ),
                      ),
                      const SizedBox(height: 8),
                      if (state.errorMessage != null)
                        Text(
                          state.errorMessage!,
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.secondaryGrey,
                          ),
                        ),
                    ],
                  ),
                );
              }

              return TabBarView(
                controller: _tabController,
                children: [
                  _buildCheckinList(state.upcomingCheckins, true),
                  _buildCheckinList(state.previousCheckins, false),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCheckinList(List<dynamic> checkins, bool isUpcoming) {
    if (checkins.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isUpcoming ? Icons.calendar_today : Icons.history,
              size: 64,
              color: AppColors.secondaryGrey.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              isUpcoming
                  ? 'No upcoming check-ins'
                  : 'No previous check-ins',
              style: AppTextStyles.bodyLarge.copyWith(
                color: AppColors.secondaryGrey,
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: AppColors.primaryBlue,
      onRefresh: () => context.read<CustomerCheckinCubit>().loadCheckins(),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: checkins.length,
        itemBuilder: (context, index) {
          return CheckinCard(checkin: checkins[index]);
        },
      ),
    );
  }
}
