import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';

enum CheckinType { single, group }

class CheckinTypeSelection extends StatefulWidget {
  final VoidCallback? onCheckInCreated;
  final Function(CheckinType)? onTypeSelected;
  
  const CheckinTypeSelection({
    super.key, 
    this.onCheckInCreated,
    this.onTypeSelected,
  });

  @override
  State<CheckinTypeSelection> createState() => _CheckinTypeSelectionState();
}

class _CheckinTypeSelectionState extends State<CheckinTypeSelection> {
  CheckinType _selectedType = CheckinType.single;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 20),
          Text(
            'Select Check-In Type',
            style: AppTextStyles.heading.copyWith(
              color: AppColors.primaryBlue,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 40),
          
          // Single Customer Radio Option
          InkWell(
            onTap: () {
              setState(() {
                _selectedType = CheckinType.single;
              });
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _selectedType == CheckinType.single
                    ? AppColors.primaryBlue.withOpacity(0.1)
                    : AppColors.cardBackground,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedType == CheckinType.single
                      ? AppColors.primaryBlue
                      : AppColors.secondaryGrey.withOpacity(0.3),
                  width: 2,
                ),
              ),
              child: Row(
                children: [
                  Radio<CheckinType>(
                    value: CheckinType.single,
                    groupValue: _selectedType,
                    activeColor: AppColors.primaryBlue,
                    onChanged: (value) {
                      setState(() {
                        _selectedType = value!;
                      });
                    },
                  ),
                  const SizedBox(width: 12),
                  Icon(
                    Icons.person,
                    size: 32,
                    color: _selectedType == CheckinType.single
                        ? AppColors.primaryBlue
                        : AppColors.secondaryGrey,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Single Customer',
                          style: AppTextStyles.bodyLarge.copyWith(
                            fontWeight: FontWeight.w600,
                            color: _selectedType == CheckinType.single
                                ? AppColors.primaryBlue
                                : AppColors.primaryBlack,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Check-in one visitor',
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.secondaryGrey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Groups of Customers Radio Option
          InkWell(
            onTap: () {
              setState(() {
                _selectedType = CheckinType.group;
              });
            },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _selectedType == CheckinType.group
                    ? AppColors.primaryBlue.withOpacity(0.1)
                    : AppColors.cardBackground,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedType == CheckinType.group
                      ? AppColors.primaryBlue
                      : AppColors.secondaryGrey.withOpacity(0.3),
                  width: 2,
                ),
              ),
              child: Row(
                children: [
                  Radio<CheckinType>(
                    value: CheckinType.group,
                    groupValue: _selectedType,
                    activeColor: AppColors.primaryBlue,
                    onChanged: (value) {
                      setState(() {
                        _selectedType = value!;
                      });
                    },
                  ),
                  const SizedBox(width: 12),
                  Icon(
                    Icons.groups,
                    size: 32,
                    color: _selectedType == CheckinType.group
                        ? AppColors.primaryBlue
                        : AppColors.secondaryGrey,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Groups of Customers',
                          style: AppTextStyles.bodyLarge.copyWith(
                            fontWeight: FontWeight.w600,
                            color: _selectedType == CheckinType.group
                                ? AppColors.primaryBlue
                                : AppColors.primaryBlack,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Check-in multiple visitors',
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.secondaryGrey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          const Spacer(),
          
          // Next Button
          ElevatedButton(
            onPressed: () {
              // Call the callback to notify parent to show form
              widget.onTypeSelected?.call(_selectedType);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBlue,
              foregroundColor: AppColors.primaryWhite,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Next',
              style: AppTextStyles.bodyLarge.copyWith(
                fontWeight: FontWeight.w600,
                color: AppColors.primaryWhite,
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
