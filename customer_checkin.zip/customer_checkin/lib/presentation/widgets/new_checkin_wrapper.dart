import 'package:flutter/material.dart';
import 'checkin_type_selection.dart';
import 'new_checkin_tab.dart';

class NewCheckinWrapper extends StatefulWidget {
  final VoidCallback? onCheckInCreated;
  
  const NewCheckinWrapper({super.key, this.onCheckInCreated});

  @override
  State<NewCheckinWrapper> createState() => _NewCheckinWrapperState();
}

class _NewCheckinWrapperState extends State<NewCheckinWrapper> {
  CheckinType? _selectedType;

  @override
  Widget build(BuildContext context) {
    // If no type selected yet, show type selection screen
    if (_selectedType == null) {
      return CheckinTypeSelection(
        onCheckInCreated: widget.onCheckInCreated,
        onTypeSelected: (type) {
          setState(() {
            _selectedType = type;
          });
        },
      );
    }
    
    // If single customer selected, show the form
    if (_selectedType == CheckinType.single) {
      return NewCheckinTab(
        onCheckInCreated: () {
          // Reset to type selection after successful creation
          setState(() {
            _selectedType = null;
          });
          // Call the parent callback
          widget.onCheckInCreated?.call();
        },
      );
    }
    
    // If group selected, show coming soon message
    return const Center(
      child: Text('Group Check-In Coming Soon'),
    );
  }
}
