import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/visit_types.dart';
import '../cubits/new_checkin_cubit.dart';
import '../cubits/customer_checkin_cubit.dart';

class NewCheckinTab extends StatefulWidget {
  final VoidCallback? onCheckInCreated;
  
  const NewCheckinTab({super.key, this.onCheckInCreated});

  @override
  State<NewCheckinTab> createState() => _NewCheckinTabState();
}

class _NewCheckinTabState extends State<NewCheckinTab> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _companyController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();
  final _dateController = TextEditingController();
  final _startTimeController = TextEditingController();
  final _endTimeController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _companyController.dispose();
    _phoneController.dispose();
    _notesController.dispose();
    _dateController.dispose();
    _startTimeController.dispose();
    _endTimeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => NewCheckinCubit(
        context.read<CustomerCheckinCubit>().repository,
      ),
      child: BlocConsumer<NewCheckinCubit, NewCheckinState>(
        listener: (context, state) async {
          if (state.status == NewCheckinStatus.success) {
            // Show floating alert overlay
            final overlay = Overlay.of(context);
            final overlayEntry = OverlayEntry(
              builder: (context) => Positioned(
                top: MediaQuery.of(context).padding.top + 20,
                left: 20,
                right: 20,
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.successGreen,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.check_circle,
                          color: Colors.white,
                          size: 24,
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            'Customer check-in created successfully!',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
            
            overlay.insert(overlayEntry);
            
            // Reload check-ins
            context.read<CustomerCheckinCubit>().loadCheckins();
            _clearForm();
            
            // Hide alert after 2 seconds and navigate to My Check-Ins tab
            await Future.delayed(const Duration(seconds: 2));
            overlayEntry.remove();
            
            if (context.mounted) {
              // Navigate to My Check-Ins tab
              widget.onCheckInCreated?.call();
            }
          } else if (state.status == NewCheckinStatus.error) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.errorMessage ?? 'Failed to create check-in'),
                backgroundColor: AppColors.errorRed,
              ),
            );
          }
        },
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(12),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Visitor Information',
                    style: const TextStyle(
                      fontFamily: 'Helvetica',
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                  const SizedBox(height: 10),
                  
                  // Visitor Name
                  TextFormField(
                    key: const Key('visitor_name_field'),
                    controller: _nameController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Visitor Name *',
                      icon: Icons.person,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter visitor name';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      context.read<NewCheckinCubit>().updateVisitorName(value);
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  // Email
                  TextFormField(
                    key: const Key('visitor_email_field'),
                    controller: _emailController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Email Address *',
                      icon: Icons.email,
                    ),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter email';
                      }
                      if (!value.contains('@')) {
                        return 'Please enter a valid email';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      context.read<NewCheckinCubit>().updateVisitorEmail(value);
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  // Company Name
                  TextFormField(
                    key: const Key('company_field'),
                    controller: _companyController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Company',
                      icon: Icons.business,
                    ),
                    onChanged: (value) {
                      context.read<NewCheckinCubit>().updateCompanyName(value);
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  // Phone Number
                  TextFormField(
                    key: const Key('phone_field'),
                    controller: _phoneController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Phone Number',
                      icon: Icons.phone,
                    ),
                    keyboardType: TextInputType.phone,
                    onChanged: (value) {
                      context.read<NewCheckinCubit>().updatePhone(value);
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  Text(
                    'Visit Details',
                    style: const TextStyle(
                      fontFamily: 'Helvetica',
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                  const SizedBox(height: 10),
                  
                  // Visit Type Dropdown
                  DropdownButtonFormField<String>(
                    key: const Key('visit_type_dropdown'),
                    value: state.visitType,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14, color: AppColors.primaryBlack),
                    decoration: _inputDecoration(
                      label: 'Visit Type *',
                      icon: Icons.business_center,
                    ),
                    items: VisitTypes.types.map((type) {
                      return DropdownMenuItem(
                        value: type,
                        child: Text(type),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        context.read<NewCheckinCubit>().updateVisitType(value);
                      }
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  // Host (Read-only)
                  TextFormField(
                    initialValue: 'Test Host',
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Host',
                      icon: Icons.person_outline,
                    ),
                    enabled: false,
                  ),
                  const SizedBox(height: 12),
                  
                  // Date Picker
                  TextFormField(
                    key: const Key('date_field'),
                    controller: _dateController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Date *',
                      icon: Icons.calendar_today,
                    ),
                    readOnly: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a date';
                      }
                      return null;
                    },
                    onTap: () async {
                      final date = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now(),
                        lastDate: DateTime.now().add(const Duration(days: 365)),
                      );
                      if (date != null) {
                        _dateController.text = DateFormat('MMM dd, yyyy').format(date);
                        
                        // Update expected time if start time is set
                        if (state.expectedAt != null) {
                          final updatedExpected = DateTime(
                            date.year,
                            date.month,
                            date.day,
                            state.expectedAt!.hour,
                            state.expectedAt!.minute,
                          );
                          context.read<NewCheckinCubit>().updateExpectedAt(updatedExpected);
                        } else {
                          // If no time set yet, create a DateTime with the selected date
                          // Time will be updated when user selects start time
                          final dateOnly = DateTime(date.year, date.month, date.day, 9, 0);
                          context.read<NewCheckinCubit>().updateExpectedAt(dateOnly);
                        }
                        
                        // Update leaving time if end time is set
                        if (state.leavingAt != null) {
                          final updatedLeaving = DateTime(
                            date.year,
                            date.month,
                            date.day,
                            state.leavingAt!.hour,
                            state.leavingAt!.minute,
                          );
                          context.read<NewCheckinCubit>().updateLeavingAt(updatedLeaving);
                        } else {
                          // If no time set yet, create a DateTime with the selected date
                          // Time will be updated when user selects end time
                          final dateOnly = DateTime(date.year, date.month, date.day, 17, 0);
                          context.read<NewCheckinCubit>().updateLeavingAt(dateOnly);
                        }
                      }
                    },
                  ),
                  const SizedBox(height: 12),
                  
                  Row(
                    children: [
                      // Start Time
                      Expanded(
                        child: TextFormField(
                          key: const Key('start_time_field'),
                          controller: _startTimeController,
                          style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                          decoration: _inputDecoration(
                            label: 'Start Time *',
                            icon: Icons.access_time,
                          ),
                          readOnly: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            return null;
                          },
                          onTap: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (time != null) {
                              _startTimeController.text = time.format(context);
                              
                              // Use selected date from state.expectedAt if available,
                              // otherwise default to tomorrow
                              final now = DateTime.now();
                              final tomorrow = now.add(const Duration(days: 1));
                              final selectedDate = state.expectedAt ?? tomorrow;
                              
                              final dateTime = DateTime(
                                selectedDate.year,
                                selectedDate.month,
                                selectedDate.day,
                                time.hour,
                                time.minute,
                              );
                              context.read<NewCheckinCubit>().updateExpectedAt(dateTime);
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      
                      // End Time
                      Expanded(
                        child: TextFormField(
                          key: const Key('end_time_field'),
                          controller: _endTimeController,
                          style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                          decoration: _inputDecoration(
                            label: 'End Time *',
                            icon: Icons.access_time,
                          ),
                          readOnly: true,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            return null;
                          },
                          onTap: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: TimeOfDay.now(),
                            );
                            if (time != null) {
                              _endTimeController.text = time.format(context);
                              
                              // Use the same date as expectedAt (from date picker or start time)
                              // If not available, default to tomorrow
                              final now = DateTime.now();
                              final tomorrow = now.add(const Duration(days: 1));
                              final selectedDate = state.expectedAt ?? tomorrow;
                              
                              final dateTime = DateTime(
                                selectedDate.year,
                                selectedDate.month,
                                selectedDate.day,
                                time.hour,
                                time.minute,
                              );
                              context.read<NewCheckinCubit>().updateLeavingAt(dateTime);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  
                  // Notes
                  TextFormField(
                    controller: _notesController,
                    style: const TextStyle(fontFamily: 'Helvetica', fontSize: 14),
                    decoration: _inputDecoration(
                      label: 'Notes',
                      icon: Icons.note,
                    ),
                    maxLines: 3,
                    onChanged: (value) {
                      context.read<NewCheckinCubit>().updateNotes(value);
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Submit Button
                  Center(
                    child: SizedBox(
                      width: 200,
                      child: ElevatedButton(
                        key: const Key('create_checkin_button'),
                        onPressed: state.status == NewCheckinStatus.loading
                            ? null
                            : () async {
                                if (_formKey.currentState!.validate()) {
                                  await context
                                      .read<NewCheckinCubit>()
                                      .createCheckin();
                                  // Navigation to My Check-Ins tab is now handled in BlocListener
                                }
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBlue,
                          foregroundColor: AppColors.primaryWhite,
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 24),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        child: state.status == NewCheckinStatus.loading
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    AppColors.primaryWhite,
                                  ),
                                ),
                              )
                            : Text(
                                'Create Check-In',
                                style: const TextStyle(
                                  fontFamily: 'Helvetica',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.primaryWhite,
                                ),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  InputDecoration _inputDecoration({
    required String label,
    required IconData icon,
  }) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(
        fontFamily: 'Helvetica',
        fontSize: 13,
      ),
      prefixIcon: Icon(icon, color: AppColors.primaryBlue, size: 20),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.borderGrey),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.borderGrey),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: AppColors.primaryBlue, width: 2),
      ),
      filled: true,
      fillColor: AppColors.primaryWhite,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
    );
  }

  void _clearForm() {
    _formKey.currentState?.reset();
    _nameController.clear();
    _emailController.clear();
    _companyController.clear();
    _phoneController.clear();
    _notesController.clear();
    _dateController.clear();
    _startTimeController.clear();
    _endTimeController.clear();
  }
}
