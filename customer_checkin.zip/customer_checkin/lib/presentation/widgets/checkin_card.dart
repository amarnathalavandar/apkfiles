import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_text_styles.dart';
import '../../data/models/customer_checkin_model.dart';
import '../cubits/customer_checkin_cubit.dart';
import '../pages/checkin_detail_page.dart';

class CheckinCard extends StatelessWidget {
  final CustomerCheckin checkin;

  const CheckinCard({super.key, required this.checkin});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: AppColors.cardBackground,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () {
          context.read<CustomerCheckinCubit>().selectCheckin(checkin);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => BlocProvider.value(
                value: context.read<CustomerCheckinCubit>(),
                child: CheckinDetailPage(checkin: checkin),
              ),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          checkin.visitorName,
                          style: AppTextStyles.bodyLarge.copyWith(
                            fontWeight: FontWeight.w600,
                            color: AppColors.primaryBlue,
                          ),
                        ),
                        if (checkin.companyName != null) ...[
                          const SizedBox(height: 4),
                          Text(
                            checkin.companyName!,
                            style: AppTextStyles.bodySmall.copyWith(
                              color: AppColors.secondaryGrey,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: _getStatusColor(checkin.status),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      _getStatusText(checkin.status),
                      style: AppTextStyles.bodySmall.copyWith(
                        color: AppColors.primaryWhite,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    size: 16,
                    color: AppColors.secondaryGrey,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _formatDate(checkin.expectedAt ?? checkin.checkinTime),
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.secondaryGrey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(
                    Icons.access_time,
                    size: 16,
                    color: AppColors.secondaryGrey,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _formatTime(checkin.expectedAt ?? checkin.checkinTime, 
                               checkin.leavingAt),
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.secondaryGrey,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(
                    Icons.business_center,
                    size: 16,
                    color: AppColors.secondaryGrey,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    checkin.visitType,
                    style: AppTextStyles.bodySmall.copyWith(
                      color: AppColors.secondaryGrey,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'upcoming':
        return AppColors.primaryBlue;
      case 'checked-in':
        return AppColors.successGreen;
      case 'checked-out':
        return AppColors.secondaryGrey;
      default:
        return AppColors.secondaryGrey;
    }
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'upcoming':
        return 'Upcoming';
      case 'checked-in':
        return 'Checked In';
      case 'checked-out':
        return 'Checked Out';
      default:
        return status;
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('MMM dd, yyyy').format(date);
  }

  String _formatTime(DateTime start, DateTime? end) {
    final startTime = DateFormat('HH:mm').format(start);
    if (end != null) {
      final endTime = DateFormat('HH:mm').format(end);
      return '$startTime - $endTime';
    }
    return startTime;
  }
}
