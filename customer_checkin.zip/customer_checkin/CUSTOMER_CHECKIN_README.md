# Customer Check-In Application

A Flutter application for managing customer check-ins with a clean, modern UI design.

## Features

### ✅ Implemented Features

1. **Home Page Entry Tile**
   - Clean card-based design with icon and description
   - Tappable tile that navigates to Customer Check-In home

2. **Customer Check-In Home Page**
   - Two main tabs: "My Check-Ins" and "New Check-In"
   - Modern tab bar with blue theme

3. **My Check-Ins Tab**
   - Sub-tabs for "Upcoming" and "Previous" check-ins
   - List of check-in cards with visitor information
   - Pull-to-refresh functionality
   - Empty state handling

4. **Check-In Detail Page**
   - Comprehensive visitor information
   - Visit details (host, type, date, time)
   - Status badges (Upcoming, Checked-In, Checked-Out)
   - Optional notes display

5. **New Check-In Tab**
   - Form to create new customer check-ins
   - Fields:
     - Visitor Name (required)
     - Email (required, validated)
     - Company Name (optional)
     - Phone (optional)
     - Visit Type (dropdown with preset types)
     - Host (read-only, displays "Test Host")
     - Date picker (required)
     - Start Time picker (required)
     - End Time picker (required)
     - Notes (optional, multiline)
   - Form validation
   - Success/error feedback

6. **Data Persistence**
   - SharedPreferences integration for local storage
   - Automatic save on new check-in creation
   - Dummy data for demonstration

7. **Visit Types**
   - Business Meeting
   - Interview
   - Delivery
   - Contractor
   - Consultation
   - Training
   - Maintenance
   - Other

8. **State Management**
   - Flutter Bloc (Cubit) for state management
   - Reactive UI updates
   - Proper loading and error states

9. **Design Constants**
   - `AppColors`: Centralized color definitions
   - `AppTextStyles`: Consistent typography
   - Modular and reusable design system

## Project Structure

```
lib/
├── core/
│   └── constants/
│       ├── app_colors.dart          # Color constants
│       ├── app_text_styles.dart     # Typography constants
│       └── visit_types.dart         # Visit type definitions
├── data/
│   ├── models/
│   │   ├── customer_checkin_model.dart         # Data model
│   │   ├── customer_checkin_model.freezed.dart # Generated
│   │   └── customer_checkin_model.g.dart       # Generated
│   └── repositories/
│       └── customer_checkin_repository.dart    # Data layer
├── presentation/
│   ├── cubits/
│   │   ├── customer_checkin_cubit.dart         # Main cubit
│   │   ├── customer_checkin_state.dart         # State definitions
│   │   ├── new_checkin_cubit.dart              # New check-in cubit
│   │   └── new_checkin_state.dart              # State definitions
│   ├── pages/
│   │   ├── customer_checkin_home_page.dart     # Main page
│   │   └── checkin_detail_page.dart            # Detail view
│   └── widgets/
│       ├── checkin_card.dart                   # Card component
│       ├── checkin_list_tab.dart               # List view
│       ├── customer_checkin_tile.dart          # Entry tile
│       └── new_checkin_tab.dart                # Form view
└── main.dart                                    # App entry point
```

## Dependencies

```yaml
dependencies:
  flutter_bloc: ^8.1.3          # State management
  equatable: ^2.0.5             # Value equality
  freezed_annotation: ^2.4.1    # Code generation
  json_annotation: ^4.8.1       # JSON serialization
  shared_preferences: ^2.2.2    # Local storage
  intl: ^0.18.1                 # Internationalization

dev_dependencies:
  build_runner: ^2.4.7          # Code generation
  freezed: ^2.4.6               # Immutable classes
  json_serializable: ^6.7.1     # JSON serialization
```

## Getting Started

### 1. Install Dependencies

```bash
flutter pub get
```

### 2. Generate Code

```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

### 3. Run the App

```bash
flutter run
```

## Usage

1. **Launch the app** - You'll see a home page with a "Customer Check-In" tile
2. **Tap the tile** - Opens the Customer Check-In home page
3. **View check-ins** - Navigate between "Upcoming" and "Previous" tabs
4. **Tap a check-in** - View detailed information about the visit
5. **Create new check-in** - Switch to "New Check-In" tab and fill out the form
6. **Submit** - Check-in is saved and appears in the appropriate list

## Dummy Data

The app comes pre-loaded with 6 dummy check-ins:
- 3 upcoming visits
- 3 previous/completed visits

This data is used when no saved data exists in SharedPreferences.

## Design Notes

- **Color Theme**: Blue primary color (#0033A0)
- **Font Family**: Roboto (can be easily changed in `AppTextStyles`)
- **Card-based UI**: Modern, clean design with rounded corners
- **Status Indicators**: Color-coded badges for check-in status
- **Responsive**: Adapts to different screen sizes

## Future Enhancements

- QR code check-in
- Photo capture for visitors
- Email notifications
- Export check-in reports
- Search and filter functionality
- Multi-language support
- Dark mode theme

## License

This project is created for demonstration purposes.
