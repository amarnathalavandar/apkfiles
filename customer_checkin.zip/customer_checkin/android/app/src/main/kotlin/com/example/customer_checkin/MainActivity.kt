package com.example.customer_checkin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
