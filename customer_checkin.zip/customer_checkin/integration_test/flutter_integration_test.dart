import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:customer_checkin/main.dart' as app;

void main() {
  // Ensure IntegrationTestWidgetsFlutterBinding is initialized
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('E2E Test - Customer Check-In', () {
    tearDownAll(() async {
      // Signal that the test is complete
      binding.reportData = <String, dynamic>{
        'completed': true,
      };
    });

    testWidgets("Test customer check-in tile click", (tester) async {
      // Start the app
      app.main();
      await tester.pumpAndSettle(); // wait for app to be ready

      // Verify the customer check-in tile is present
      final tileFinder = find.byKey(const Key('customer_checkin_tile'));
      expect(tileFinder, findsOneWidget);

      // Tap on the customer check-in tile
      await tester.tap(tileFinder);
      await tester.pumpAndSettle();

      // Verify navigation to Customer Check-In Home Page
      // by checking for the presence of the AppBar with title
      expect(find.text('Customer Check-In'), findsOneWidget);

      // Verify tabs are present
      expect(find.text('My Check-Ins'), findsOneWidget);
      expect(find.text('New Check-In'), findsOneWidget);
    });

    testWidgets("Test adding a new customer check-in with sample data", (tester) async {
      // Start the app
      app.main();
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Navigate to check-in page
      final tileFinder = find.byKey(const Key('customer_checkin_tile'));
      await tester.tap(tileFinder);
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Switch to "New Check-In" tab
      await tester.tap(find.text('New Check-In'));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Select "Single Customer" radio button (should be selected by default)
      final singleCustomerRadio = find.text('Single Customer');
      expect(singleCustomerRadio, findsOneWidget);
      await tester.tap(singleCustomerRadio);
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Click Next button
      await tester.tap(find.text('Next'));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Now we should be on the form page
      // Fill in visitor information
      await tester.enterText(
        find.byKey(const Key('visitor_name_field')),
        'John Doe',
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      await tester.enterText(
        find.byKey(const Key('visitor_email_field')),
        'john.doe@example.com',
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      await tester.enterText(
        find.byKey(const Key('company_field')),
        'Acme Corporation',
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      await tester.enterText(
        find.byKey(const Key('phone_field')),
        '+1 555-123-4567',
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Select visit type
      await tester.tap(find.byKey(const Key('visit_type_dropdown')));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));
      await tester.tap(find.text('Business Meeting').last);
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Select date - select tomorrow's date
      await tester.tap(find.byKey(const Key('date_field')));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));
      
      // Calculate tomorrow's day
      final tomorrow = DateTime.now().add(const Duration(days: 1));
      final tomorrowDay = tomorrow.day.toString();
      
      // Try to find and tap tomorrow's date in the calendar
      final tomorrowFinder = find.text(tomorrowDay);
      if (tomorrowFinder.evaluate().isNotEmpty) {
        // Tap the last occurrence (in case day number appears multiple times)
        await tester.tap(tomorrowFinder.last);
        await tester.pumpAndSettle();
        await Future.delayed(const Duration(milliseconds: 500));
      }
      
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Scroll to make time fields visible
      await tester.drag(
        find.byType(SingleChildScrollView),
        const Offset(0, -300),
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Select start time
      await tester.tap(find.byKey(const Key('start_time_field')));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Select end time
      await tester.tap(find.byKey(const Key('end_time_field')));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Scroll to bottom to see the submit button
      await tester.drag(
        find.byType(SingleChildScrollView),
        const Offset(0, -300),
      );
      await tester.pumpAndSettle();
      await Future.delayed(const Duration(milliseconds: 500));

      // Tap create check-in button
      await tester.tap(find.byKey(const Key('create_checkin_button')));
      await tester.pumpAndSettle();

      // Wait 2 seconds for data to be saved
      await Future.delayed(const Duration(seconds: 2));
      await tester.pumpAndSettle();

      // Verify the newly created check-in appears in the Upcoming visits
      expect(find.text('John Doe'), findsOneWidget);
    });
  });
}
