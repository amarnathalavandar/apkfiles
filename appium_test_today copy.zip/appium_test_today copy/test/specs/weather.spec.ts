import { browser, expect } from '@wdio/globals';
// @ts-ignore
import FlutterIntergrationDriverService from 'wdio-flutter-by-service';

describe('Weather app smoke', () => {
  it('Open and tap temperature button', async () => {
    console.log('[TEST] Starting: Weather app temperature button');

    // Give the app time to start
    await browser.pause(5000);

    // Wait for a known widget to confirm the Flutter bridge is ready
  
    // Try by ValueKey (as defined in Dart)
    const byKeyFinder = browser.flutterByValueKey$('temperature_button');
    byKeyFinder.click();
    // Get the element via finder
    let btn = await browser.flutterByValueKey$('temperature_button');

    // If not found, try Semantics label (also set in Dart)
    if (!(await btn.isExisting?.())) {
      console.log('[TEST] Falling back to Semantics label: temperature_button');
      const bySemanticsFinder = browser.flutterBySemanticsLabel$('temperature_button');
      btn = await browser.flutterBySemanticsLabel$('temperature_button');
    }

   

    console.log('[TEST] Clicking the temperature button');
    await btn.click();

    console.log('[TEST] Done: tapped temperature button');
  });
});