import type { Options } from '@wdio/types'

export const config: Options.Testrunner = {
  runner: 'local',
  specs: ['./../specs/**/*.ts'],
  maxInstances: 1,
  logLevel: 'info',
  framework: 'mocha',
  mochaOpts: { ui: 'bdd', timeout: 120000 },
  reporters: ['spec'],
  autoCompileOpts: {
    autoCompile: true,
    tsNodeOpts: { transpileOnly: true, project: './tsconfig.json' }
  },
  services: [
    ['appium', {}],
    ['flutter-by', {}]
  ],
  capabilities: [{
    platformName: 'Android',
    'appium:automationName': 'FlutterIntegration',
    'appium:deviceName': 'ZA222MLMTR',
    'appium:app': '/Users/AMARNATH.ALAVANDAR/Projects/sourcecode/Sauce_Labs/weather_app/weather_app/build/app/outputs/flutter-apk/app-debug.apk',
    'appium:autoGrantPermissions': true,
    'appium:newCommandTimeout': 120,
    'appium:flutterSystemPort': 22455,
    // Optional: add explicit app identifiers once known
    'appium:appPackage': 'com.example.weather_app',
     'appium:appActivity': '.MainActivity'
  }],
  hostname: '127.0.0.1',
  port: 4723,
  path: '/'
}